package com.cg.jpa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.jpa.entity.Employee;

@Controller
public class EmployeeController {
	
	@RequestMapping("/index")
	public String getHomePage()
	{
		return "index";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saveEmployee(Employee employee, Model model)
	{
		return "index";
	}
	
}

