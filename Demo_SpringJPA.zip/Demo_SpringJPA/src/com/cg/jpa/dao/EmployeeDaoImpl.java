package com.cg.jpa.dao;

import java.util.List;
import com.cg.jpa.entity.Employee;

public class EmployeeDaoImpl {

	public Employee save(Employee employee) {
		return employee;

	}

	public List<Employee> loadAll() {
		return null;

	}

}
