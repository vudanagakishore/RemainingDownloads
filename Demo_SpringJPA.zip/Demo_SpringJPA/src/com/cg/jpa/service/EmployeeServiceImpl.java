package com.cg.jpa.service;
import java.util.List;
import com.cg.jpa.dao.EmployeeDaoImpl;
import com.cg.jpa.entity.Employee;

public class EmployeeServiceImpl {

	EmployeeDaoImpl dao = new EmployeeDaoImpl();

	public Employee save(Employee employee) {
		return dao.save(employee);

	}

	public List<Employee> loadAll() {
		return null;

	}

}

