package com.cg.SpringBootRestJpa.service;

import java.util.List;

import com.cg.SpringBootRestJpa.entity.Products;

public interface ProductService {
	 public List<Products> addProduct(Products pro);
	    
	    public void deleteProduct(String id);
	    public List<Products> getAllProducts();
	    public List<Products> updateProduct(String id, Products pro);
	    public Products getProductsById(String id);
	    
}
