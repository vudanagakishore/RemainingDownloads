package com.cg.SpringBootRestJpa.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.SpringBootRestJpa.entity.Products;
@Repository
public interface ProductDao extends JpaRepository<Products, String>{
   
	@Query("from Products where id=:c")
	Optional<Products> findById(@Param("c")String id);
	
	@Query("from Products where id=:c")
	void deleteById(@Param("c")String id);
}
