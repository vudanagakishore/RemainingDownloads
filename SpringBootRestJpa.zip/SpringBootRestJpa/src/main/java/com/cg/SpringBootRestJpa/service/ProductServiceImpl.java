package com.cg.SpringBootRestJpa.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBootRestJpa.dao.ProductDao;
import com.cg.SpringBootRestJpa.entity.Products;

 
@Service
public class ProductServiceImpl implements ProductService{
    @Autowired
    ProductDao productDao;

 

    @Override
    public List<Products> addProduct(Products pro) {
        productDao.save(pro);
        return productDao.findAll();
        
    }
    @Override
    public void deleteProduct(String id) {
        productDao.deleteById(id);
           
    }
    @Override
    public List<Products> getAllProducts() {
        return productDao.findAll();
     }
    
    @Override
    public List<Products> updateProduct(String id, Products pro) {
        Optional<Products> optional=productDao.findById(id);
        if(optional.isPresent())
        {
            Products product=optional.get();
            product.setName(pro.getName());
            product.setModel(pro.getModel());
            product.setPrice(pro.getPrice());
            
            productDao.save(product);
            
        }
        return getAllProducts();
    }

    @Override
    public Products getProductsById(String id) {
        // TODO Auto-generated method stub
        return productDao.findById(id).get();
    }

}
	