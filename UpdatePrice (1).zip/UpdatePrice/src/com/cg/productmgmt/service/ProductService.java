package com.cg.productmgmt.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService
{
 
}