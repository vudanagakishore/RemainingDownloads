package com.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client 
{
    /**
        Refer the sample input and output for the presentation layer messages
        Do not use tab or extra newline, which will lead to presentation error.
        Do not provide any additional messages, which is not asked for
    */
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
    }
}