package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.exception.ProductException;


public class ProductDAO implements IProductDAO
{
 
	
	//map for ProductName as key and Category as value
	
		private static Map<String,String> productDetails;	
		
		//map for Product name as key  and price as value value
		
		private static Map<String,Integer> salesDetails;		

		
		//Getter and Setter
		
		public static Map<String, Integer> getSalesDetails() {
			return salesDetails;
		}

		public static void setSalesDetails(Map<String, Integer> salesDetails) {
			ProductDAO.salesDetails = salesDetails;
		}

		public static void setProductDetails(Map<String, String> productDetails) {
			ProductDAO.productDetails = productDetails;
		}
		
		//implement methods in the interface
}


