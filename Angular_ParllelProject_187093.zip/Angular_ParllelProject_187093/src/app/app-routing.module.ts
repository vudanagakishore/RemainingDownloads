import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddmountComponent } from '../app/addmount/addmount.component';
import { HomeComponent } from '../app/home/home.component';
import { ViewaccountComponent } from '../app/viewaccount/viewaccount.component';
import { ViewallaccountComponent } from '../app/viewallaccount/viewallaccount.component';
import { MoneytransferComponent } from '../app/moneytransfer/moneytransfer.component';
import { AccountcreationComponent } from '../app/accountcreation/accountcreation.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
const routes: Routes = [
  {
  path: 'addmoney',
  component: AddmountComponent
},
{
  path: 'viewaccount',
  component: ViewaccountComponent
},
{
  path: 'withdraw',
  component: WithdrawComponent
},
{
  path: 'viewall',
  component: ViewallaccountComponent
},
{
  path: 'moneytransfer',
  component: MoneytransferComponent
},
{
  path: 'account',
  component: AccountcreationComponent
},
{
  path: '',
  component: HomeComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
