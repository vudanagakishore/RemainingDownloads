package com.cg.bean;


public class Bank 
{
	private String name;
	private long accNo;
	private int pin;
	private String address;
	private String phoneNo;
	private int balance;
	
	String trans = new String();

	
	
	
	
	/**
	 * 
	 */
	public Bank() {
		super();
	}
	
	
	
	
	

	/**
	 * @param name
	 * @param accNo
	 * @param pin
	 * @param address
	 * @param phoneNo
	 * @param balance
	 * @param trans
	 */
	public Bank(String name, long accNo, int pin, String address, String phoneNo, int balance, String trans) {
		super();
		this.name = name;
		this.accNo = accNo;
		this.pin = pin;
		this.address = address;
		this.phoneNo = phoneNo;
		this.balance = balance;
		this.trans = trans;
	}






	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the accNo
	 */
	public long getAccNo() {
		return accNo;
	}

	/**
	 * @param accNo the accNo to set
	 */
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	/**
	 * @return the pin
	 */
	public int getPin() {
		return pin;
	}

	/**
	 * @param pin the pin to set
	 */
	public void setPin(int pin) {
		this.pin = pin;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	/**
	 * @return the balance
	 */
	public int getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 * @return 
	 */
	public int setBalance(int balance) {
		return this.balance = balance;
	}

	/**
	 * @return the trans
	 */
	public String getTrans() {
		return trans;
	}

	/**
	 * @param trans the trans to set
	 */
	public void setTrans(String trans) {
		this.trans = trans;
	}






	@Override
	public String toString() {
		return "AccountDetails name =" + name + "\n accNo =" + accNo + "\n pin =" + pin + "\n add =" + address
				+ "\n phone =" + phoneNo + "\nbalance =" + balance;
	}

	
	
	
}
