package com.cg.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bean.BankTransaction;
import com.cg.exceptions.AccountAlreadyExistsException;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.LowBalanceException;
import com.cg.service.BankServiceImpl;
import com.cg.service.IBankService;



public class BankUi {
	static Scanner scannerObj = new Scanner(System.in);
	static BankTransaction trans = new BankTransaction();
	static BankTransaction trans1 = new BankTransaction();
	
	

	public static void main(String[] args) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		// variables

		long accNo, accNo1;
		int withdraw_amount, deposit_amount = 0, transfer_amount = 0;
		int pin;
		int amount = 0;
		int balance = 0;
		boolean result = false;
		IBankService service = new BankServiceImpl();

		/**
		 * Menu For User
		 */
		while(true) 
		
		{
			
			System.out.println("------------Welcome To Your Bank----------");
			System.out.println("choose 1 to Create Account");
			System.out.println("choose 2 to Show Balance");
			System.out.println("choose 3 to Deposit");
			System.out.println("choose 4 to Withdraw");
			System.out.println("choose 5 to Transer Fund");
			System.out.println("choose 6 to Print Transcations");
			System.out.println("choose 7 to Exit");
			
			int choice = scannerObj.nextInt();
			scannerObj.nextLine();
			switch (choice) {

			/**
			 * This case is for to create account
			 */


			case 1:

				System.out.println("Enter Your Name");
				String name = scannerObj.nextLine();
				
				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Invalid Format of Name");
					System.out.println("Enter Your Name");
					name = scannerObj.next();
				}

				System.out.println("Enter Your Address ");
				String add = scannerObj.nextLine();
				

				while (!add.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.println("Enter Your Address ");
					add = scannerObj.nextLine();

				}

				System.out.println("Enter Contact number");
				String phone = scannerObj.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Phone number should be 0f 10 digits");
						System.out.println("Enter Your Contact number");
						phone = scannerObj.next();
					}
					System.out.println("Contact number should start from 6-9");
					System.out.println("Enter Your Contact Number");
					phone = scannerObj.next();
				}

				accNo = Long.parseLong(phone) % 10000;

				System.out.println("Enter Your Pin");
				pin = scannerObj.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin number should be 0f 4 digits");
					System.out.println("Enter Your Pin");
					pin = scannerObj.nextInt();
				}

				System.out.println("Enter Balance To Your Account");
				int bal = scannerObj.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter Balance");
					bal = scannerObj.nextInt();

				}
				try {
					result = service.createAccount(name, add, accNo, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (result == true) {
					System.out.println("Account Created Successfully : " + accNo + " !!!");
					

					int trans_id = ((int) Math.random() * 1000 + 1000);
					trans.setAccNo(accNo);
					trans.setType("Create");
					trans.setAmount(bal);
					trans.setTransaction_id(trans_id);

					service.setTransactions(trans);

				} else {

					System.out.println("Cannot Create Account");
				}

				break;

				/**
				 * This case is to show balance
				 */
			case 2:

				System.out.println("Enter Your Account Number");
				accNo = scannerObj.nextLong();

				try {
					balance = service.showBalance(accNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance :" + balance);

				break;

				/**
				 * This case is to deposit amount
				 */

			case 3:

				System.out.println("Enter Your Account Number");
				accNo = scannerObj.nextLong();

				System.out.println("Enter Amount You Want To Deposit");
				deposit_amount = scannerObj.nextInt();

				try {
					amount = service.deposit(accNo, deposit_amount);

					balance = service.showBalance(accNo);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + deposit_amount);
				System.out.println("Current Balance : " + balance);

				int trans_id = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accNo);
				trans.setType("Deposit");
				trans.setAmount(deposit_amount);
				trans.setTransaction_id(trans_id);
				service.setTransactions(trans);

				break;

				/**
				 * This case is to withdraw amount
				 */


			case 4:

				System.out.println("Enter Your Account Number");
				accNo = scannerObj.nextLong();

				System.out.println("Enter Amount You Wany To withdraw");
				withdraw_amount = scannerObj.nextInt();

				try {
					amount = service.withdraw(accNo, withdraw_amount);
					result = service.validateBalance(accNo, withdraw_amount);
					balance = service.showBalance(accNo);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdraw_amount);
				System.out.println("Current Balance : " + balance);

				int trans_id1 = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accNo);
				trans.setType("Withdraw");
				trans.setAmount(withdraw_amount);
				trans.setTransaction_id(trans_id1);
				service.setTransactions(trans);

				break;

				/**
				 * This case is to fund transfer
				 */

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter Your Account Number");
				accNo = scannerObj.nextLong();

				System.out.println("Enter Account Number To Which You Want To Transfer Fund");
				accNo1 = scannerObj.nextLong();

				System.out.println("Enter Amount To Transfer");
				transfer_amount = scannerObj.nextInt();

				try {
					result = service.validateBalance(accNo, transfer_amount);
					result = service.transferfund(accNo, accNo1, transfer_amount);

					senders_balance = service.showBalance(accNo);
					recievers_balance = service.showBalance(accNo1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully");
				System.out.println("Current balance for Account " + accNo + " : " + senders_balance);

				int trans_id_1 = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accNo);
				trans.setType("Transfer");
				trans.setAmount(transfer_amount);
				trans.setTransaction_id(trans_id_1);
				service.setTransactions(trans);

				int trans_id_2 = ((int) Math.random() * 1000 + 1000);
				trans1.setAccNo(accNo1);
				trans1.setType("Transfer");
				trans1.setAmount(transfer_amount);
				trans1.setTransaction_id(trans_id_2);
				service.setTransactions(trans1);

				break;

				/**
				 * This case is to print transaction
				 */
			case 6:

				System.out.println("Enter Your Account number");
				accNo = scannerObj.nextLong();
				trans = service.getTransactions(accNo);
				if (trans == null) {
					throw new AccountNotFoundException();
				} else {
					System.out.println("--------Transactions----------");
					System.out.println("Transaction type : " + trans.getType());
					System.out.println("Transaction Id : " + trans.getTransaction_id());
					System.out.println("Transaction Account : " + trans.getAccNo());
					System.out.println("Transaction Amount : " + trans.getAmount());
				}
				break;
				
				/**
				 * This case is to exit by user
				 */

			case 7:
				System.out.println("Thank You For Using Our Service");
				System.exit(0);
				break;
			
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
			

			}
		}

	}

	
}
