package com.cg.dao;


import java.util.HashMap;

import com.cg.bean.Bank;



public class BankDaoImpl implements IBankDao {

	HashMap h1;

	public BankDaoImpl() {

		h1 = new HashMap();
	}

	// bean class object

	Bank bean = new Bank();

	// to check account already exists or not

	public Bank checkAccount(long accNo) {

		if (h1.containsKey(accNo)) {

			bean = (Bank) h1.get(accNo);
			return bean;

		} else

			return null;
	}

	// to put the data into the map

	public void setData(long accNo, Bank bean) {

		h1.put(accNo, bean);
	}

}

