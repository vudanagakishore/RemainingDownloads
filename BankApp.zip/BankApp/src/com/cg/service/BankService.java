package com.cg.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.cg.bean.Customer;

public interface BankService {

	Customer saveCustomer(Customer c);

	Map<Long, Customer> showBalance(String accnum);

	void withdrawAmount(String accnum1,double amt1);

	double fundTransfer(String yaccnum, String raccnum, double amt) throws IOException;

	ArrayList<String> printTransaction(String acc_num);

	void depositAmount(String acnum, double amt);

}
