package com.cg.mobshop.utility;

import java.util.Comparator;

import com.cg.mobshop.dto.Mobiles;

public class SortByMobilePrice implements Comparator<Mobiles>{

		@Override
		public int compare(Mobiles p1, Mobiles p2) {
			if(p1.getPrice()>p2.getPrice())
				return 1;
			else if(p1.getPrice()<p2.getPrice())
				return -1;
			else
			    return 0;
		}
}
