package com.cg.mobshop.ui;

import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;
import com.cg.mobshop.utility.SortByMobileId;
import com.cg.mobshop.utility.SortByMobileName;
import com.cg.mobshop.utility.SortByMobilePrice;


/**
 * @author ryalla
 *
 */

/*
 * main method
 */

public class MainUI {
	public static void main(String[] args) {
		MobileService service=new MobileServiceImpl();
		Scanner scanner = null;
		int choice = 0;
		boolean optionFlag = false;
		boolean choiceFlag = false;
		boolean deleteFlag = false;
		try {
			do {
				scanner = new Scanner(System.in);
				List<Mobiles> mobilelist = service.getAllMobiles();
				for (Mobiles mobile : mobilelist) {
					System.out.println(mobile);
				}
				System.out.println("*****Welcome to Mobile Shopee App *****");
				System.out.println("Enter your choice");
				System.out.println("1.Sorting\n2.Delete\n3.Exit");
				choice = scanner.nextInt();
				
				switch (choice) {
				case 1:
					System.out.println("1.SortByMobileName\n2.SortByMobilePrice\n3.SortByMobileId");
					int option = scanner.nextInt();
					switch (option) {
					/*
					 * sort by name ,sort by price, sort by id will sort the data based on option
					 */
					case 1:
					List<Mobiles> mobilelistbyname = service.getAllMobiles();
					Collections.sort(mobilelistbyname, new SortByMobileName());
					display(mobilelistbyname);
					break;
					case 2:
						/*
						 * getAllMobiles will get the data using service Object
						 */
						List<Mobiles> mobilelistbyprice = service.getAllMobiles();
						Collections.sort(mobilelistbyprice, new SortByMobilePrice());
						display(mobilelistbyprice);
						break;
					case 3:
						/*
						 * getAllMobiles will get the data using service Object
						 */
						List<Mobiles> mobilelistbypid = service.getAllMobiles();
						Collections.sort(mobilelistbypid, new SortByMobileId());
						display(mobilelistbypid);
						break;
					default:
						break;
					}
					break;
					
					
				case 2: {
					
					do {
						System.out.println("Enter Mobile Id to delete");
						int mobileId=scanner.nextInt();
						/*
						 *  delete method will delete the data based on Id
						 */
						boolean status=service.deleteMobile(mobileId);
						if(status=true) {
							System.out.println( mobileId+ "  Deleted Successfully......");
							deleteFlag=true;
						}else {
							System.out.println("Id not available...");
							
						}
							
					}while(!deleteFlag);
				}
					break;
					
				case 3:
					System.out.println("Thank u !! Visit again..");
					/*
					 * exit method will terminate the operations 
					 */
					System.exit(0);
					break;
				default:
					System.err.println("Enter 1, or 4 only");
					break;	
				}
				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Good Bye...!!!");
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);
			} while (!choiceFlag);
		} catch (InputMismatchException e) {
			System.err.println("Enter only digits");
		}

	}

	static void display(List<Mobiles>mobilelist) {
		for(Mobiles mobile : mobilelist) {
			System.out.println(mobile);
		}
}
}