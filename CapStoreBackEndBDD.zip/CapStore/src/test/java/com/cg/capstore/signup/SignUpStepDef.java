package com.cg.capstore.signup;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.capstore.pagebean.SignUpPageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SignUpStepDef {
	
	private WebDriver driver;
	private SignUpPageFactory signUpPageFactory;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\niKish\\Documents\\JARS & DRIVERS\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@After
	public void close() throws InterruptedException {
		driver.close();
	}

	@Given("^User is on 'signup' Page$")
	public void user_is_on_signup_Page() throws Throwable {
		driver.get("http://localhost:4200/customerSignup");
		signUpPageFactory = new SignUpPageFactory(driver);
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		signUpPageFactory.setFname("Nitin");
		signUpPageFactory.setLname("Singh");
		signUpPageFactory.setEmail("nitin7570@gmail.com");
		signUpPageFactory.setMobile("8937011919");
		signUpPageFactory.setPassword("nitin@123");
		signUpPageFactory.setAddress("Dehradun");
		signUpPageFactory.setBalance("50000");
		signUpPageFactory.setSubmit();
	}

	@When("^click on 'OK'$")
	public void click_on_OK() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Then("^display 'homepage' Page$")
	public void display_homepage_Page() throws Throwable {
		String expectedTitle = "CapStore: A Ecommerce Online Shopping :: Home";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}
	
}
