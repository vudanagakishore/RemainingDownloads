package com.cg.capstore.login;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.capstore.pagebean.LogInPageFactory;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LogInStepDef {

	LogInPageFactory logInPageFactory;
	private WebDriver driver;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\niKish\\Documents\\JARS & DRIVERS\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void close() throws InterruptedException {
		driver.close();
	}

	@Given("^User is on 'login' Page$")
	public void user_is_on_signup_Page() throws Throwable {
		driver.get("http://localhost:4200/customerlogin");
		logInPageFactory = new LogInPageFactory(driver);
	}

	@When("^user enters invalid UserName and password$")
	public void user_enters_invalid_UserName_and_password() throws Throwable {
		logInPageFactory.setUsername("nitin7570@gmail.com");
		logInPageFactory.setPassword("INVALIDPASSWORD");
	}

	@Then("^user is on the 'login' page$")
	public void user_is_on_the_login_page() throws Throwable {
		String expectedTitle = "CapStore: A Ecommerce Online Shopping :: Home";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		logInPageFactory.setUsername("nitin7570@gmail.com");
		logInPageFactory.setPassword("nitin@123");
	}

	@Then("^display 'customerprofile' Page$")
	public void display_customerprofile_Page() throws Throwable {
		String expectedTitle = "CapStore: A Ecommerce Online Shopping :: Home";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}

}
