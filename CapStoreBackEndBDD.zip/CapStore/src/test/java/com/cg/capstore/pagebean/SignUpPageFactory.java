package com.cg.capstore.pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SignUpPageFactory {

	WebDriver driver;

	@FindBy(id = "exampleInputName1")
	@CacheLookup
	private WebElement fname;

	@FindBy(id = "exampleInputName2")
	@CacheLookup
	private WebElement lname;

	@FindBy(id = "exampleInputEmail1")
	@CacheLookup
	private WebElement email;

	@FindBy(id = "exampleInputNumber1")
	@CacheLookup
	private WebElement mobile;

	@FindBy(id = "exampleInputPassword1")
	@CacheLookup
	private WebElement password;

	@FindBy(id = "exampleInputPassword2")
	@CacheLookup
	private WebElement cpassword;

	@FindBy(id = "exampleInputTextArea")
	@CacheLookup
	private WebElement address;

	@FindBy(id = "exampleInputName3")
	@CacheLookup
	private WebElement balance;

	@FindBy(how = How.NAME, using = "submit")
	@CacheLookup
	private WebElement submit;

	public SignUpPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getCpassword() {
		return cpassword;
	}

	public void setCpassword(String cpassword) {
		this.cpassword.sendKeys(cpassword);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance.sendKeys(balance);
	}

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}

}
