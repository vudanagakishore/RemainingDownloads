import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule}from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdddataComponent } from './adddata/adddata.component';
import { FetchdataComponent } from './fetchdata/fetchdata.component';
import { SearchdataComponent } from './searchdata/searchdata.component';
import { OrderbyPipe } from './orderby.pipe';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ServicService } from './service.service';


@NgModule({
  declarations: [
    AppComponent,
    AdddataComponent,
    FetchdataComponent,
    SearchdataComponent,
    OrderbyPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,ServicService],
  bootstrap: [AppComponent]
})
export class AppModule { }
