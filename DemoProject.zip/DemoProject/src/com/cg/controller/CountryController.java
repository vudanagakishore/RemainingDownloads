package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Country;
import com.cg.service.ICountryService;
@RestController
public class CountryController {
	@Autowired
	ICountryService service;
	//@RequestMapping(value="/countries/search/(id)",method=RequestMethod.GET.headers="Accept=application/json")

public List<Country> getAllCountries(Model model)
{
	return service.getAllCountries();
}
}
