package com.cg.dao;

import java.util.List;

import com.cg.entity.Country;

 
public interface ICountryDao {
public abstract List<Country> getAllCountries();

 

}