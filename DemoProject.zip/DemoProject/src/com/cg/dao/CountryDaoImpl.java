package com.cg.dao;

import java.util.List;

import com.cg.db.CountryDb;
import com.cg.entity.Country;

public class CountryDaoImpl implements ICountryDao {

	@Override
	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return  CountryDb.getCountryList();
	}
	

}
