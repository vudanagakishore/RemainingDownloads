package com.cg.db;

import java.util.ArrayList;

import com.cg.entity.Country;

public class CountryDb {
	private static ArrayList<Country>countryList=new ArrayList<Country>();
	static {
		countryList.add(new Country("1001","India","3234567"));
		countryList.add(new Country("1002","Pakistan","74567"));
		countryList.add(new Country("1003","SriLanka","34567"));
		countryList.add(new Country("1004","China","454567"));
		countryList.add(new Country("1005","USA","1234567"));
		
	}
	public static ArrayList<Country> getCountryList() {
		return countryList;
	}
	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDb.countryList =(ArrayList<Country>) countryList;
	}

}
