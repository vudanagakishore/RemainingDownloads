package com.cg.service;

import java.util.List;

import com.cg.entity.Country;

public interface ICountryService {

	List<Country> getAllCountries();

}
