package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICountryDao;
import com.cg.entity.Country;
@Service
public class CountryServiceImpl implements ICountryService {
	
	 ICountryDao countryDao;
	    @Autowired
	    @Override
	    public List<Country> getAllCountries() {
	        // TODO Auto-generated method stub
	        return countryDao.getAllCountries();

	
	    }
}
