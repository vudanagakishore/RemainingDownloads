package com.fg.importOrder.importOrder.service;

import java.util.List;

import com.fg.importOrder.importOrder.OrderException.OrderException;
import com.fg.importOrder.importOrder.bean.Import;

public interface ImportService {

	List<Import> getAllOrders() throws OrderException;

	List<Import> addOrder(Import p) throws OrderException;

	List<Import> updateOrder(int id, Import pro) throws OrderException;
	
	List<Import> findByQuantity(int price,int price1) throws OrderException;

	List<Import> findByAmount(double amount) throws OrderException;

	
}
