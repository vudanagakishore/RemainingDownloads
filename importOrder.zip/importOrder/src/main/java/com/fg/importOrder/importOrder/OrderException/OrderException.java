package com.fg.importOrder.importOrder.OrderException;

public class OrderException extends Exception {
	
public OrderException() 
{	
	
}	
	public OrderException(String msg) 
	{
		super(msg);
	}
}
