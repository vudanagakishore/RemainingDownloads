package com.fg.importOrder.importOrder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fg.importOrder.importOrder.OrderException.OrderException;
import com.fg.importOrder.importOrder.bean.Import;
import com.fg.importOrder.importOrder.service.ImportService;


@RestController
public class ImportController {
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Order id is not found")
	 @ExceptionHandler({Exception.class})
	public void handleException() 
		{
			
	    }
	
	@Autowired
	ImportService importservice;
	
	@RequestMapping("/getallorders")
	public List<Import> getAllProducts()  throws OrderException         ////for display of all product orders
	{
		return importservice.getAllOrders();
	}
	
	@PostMapping("/addorder")
	public List<Import> addProduct(@RequestBody Import impl) throws OrderException
	{
		return importservice.addOrder(impl);
		
	}
	
	@PutMapping("/updateorder/{id}")
	public List<Import> updateProduct(@PathVariable int id,@RequestBody Import imp) throws OrderException
	{
	
		return importservice.updateOrder(id,imp);
    }
	
	@RequestMapping("/getByquantity/{quantity}/{quantity1}")
	public List<Import> getByprice(@PathVariable int quantity,@PathVariable int quantity1) throws OrderException
	{
		return importservice.findByQuantity(quantity,quantity1);
	}
	
	
	@RequestMapping("/getByamount/{amount}")
	public List<Import> getByprice(@PathVariable double amount) throws OrderException
	{
		return importservice.findByAmount(amount);
	}

	

}
