package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class FeedbackDAO implements IFeedbackDAO {
	Map<String, Integer> MathFeedbackMap=new HashMap<String, Integer>();
	Map<String, Integer> EnglishFeedbackMap=new HashMap<String, Integer>();
	Map<String, Integer> FeedbackMap=new HashMap<String, Integer>();
	//method to add the details into respective map and returning the map
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		// TODO Auto-generated method stub
		FeedbackMap.clear();
		if(subject.equalsIgnoreCase("Math"))
		{
			MathFeedbackMap.put(name, rating);
			FeedbackMap.putAll(MathFeedbackMap);;
		}
		else if(subject.equalsIgnoreCase("English"))
		{
			EnglishFeedbackMap.put(name, rating);
			FeedbackMap.putAll(EnglishFeedbackMap);
		}
		return FeedbackMap;
	}

	//method to return the consolidated map
	//achieved by intially adding math map to the consolidated map
	//then checking if english map has same key and updating the rating if found
	//or if the key is not present it will just add the value to consolidated map
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		Set englishset=EnglishFeedbackMap.entrySet();
		Iterator i=englishset.iterator();
		String string;
		FeedbackMap.putAll(MathFeedbackMap);
		while(i.hasNext())
		{
			Map.Entry<String, Integer> me=(Map.Entry<String, Integer>)i.next();
			string=me.getKey();
			if(FeedbackMap.containsKey(string))
			{
				int temp=FeedbackMap.get(string);
				if(temp<me.getValue())
				{
					FeedbackMap.remove(string);
					FeedbackMap.put(string, me.getValue());
				}
			}
			else
			{
				FeedbackMap.put(string, me.getValue());
			}
		}
		return FeedbackMap;
	}

}
