
	public abstract class MediaItem extends Item 
	{
		private int Runtime;
		public MediaItem(int id, String title, int copies) {
			super();
			
			// TODO Auto-generated constructor stub
		}
		public void MediaItem1(int id, String title, int copies) {
			// TODO Auto-generated constructor stub
		}
		public int getRuntime() {
			return Runtime;
		}
		public void setRuntime(int runtime) {
			Runtime = runtime;
		}
		

	}



