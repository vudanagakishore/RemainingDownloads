public class Video extends MediaItem 
{
	private String director;
	private String genre;
	private int year;

	public Video(int id, String title, int copies) {
		super(id, title, copies);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) 
	{
		
		// TODO Auto-generated method stub

	}

}