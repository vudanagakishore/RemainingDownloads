public class WrittenItem extends MediaItem 
{
	private String director;
	private String genre;
	private int year;

	public WrittenItem(int id, String title, int copies) {
		super(id, title, copies);
		// TODO Auto-generated constructor stub
	}

	public void WrittenItem1(int id, String title, int copies) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) 
	{
		
		// TODO Auto-generated method stub

	}

}