package lab2;


	import java.util.Scanner;
	public class Exercise5{ 
	    public static void main(String args[]) {
	        Scanner sc=new Scanner(System.in);
	        System.out.println("enter your first name ");
	        String s1=sc.next();
	        System.out.println("enter your last name ");
	        String s2=sc.next();
	        sc.close();
	        try {
	            if(s1!= null && s1.length() != 0){
	                  System.out.println(s1);  
	             }
	                else System.out.println(s1);        
	            if(s2 != null && s2.length() != 0) { 
	                    System.out.println(s2);  
	                }
	                else System.out.println(s2);  
	        }
	        finally {
	        }
	        }
	}
