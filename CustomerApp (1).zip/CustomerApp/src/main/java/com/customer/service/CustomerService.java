package com.customer.service;

import java.util.List;


import com.customer.bean.Customer1;
import com.customer.exception.CustomerException;

public interface CustomerService {

	public List<Customer1> addCustomer(Customer1 cust) throws CustomerException;
	public Customer1 getCustomerById(int Id) throws CustomerException;
	public void deleteCustomer (int id) throws CustomerException;
	public List<Customer1> getAllCustomer() throws CustomerException;
	public List<Customer1> getCustomerByCity(String city) throws CustomerException;
	public List<Customer1> updateCustomer(int id, Customer1 cust) throws CustomerException;
	
	
}
