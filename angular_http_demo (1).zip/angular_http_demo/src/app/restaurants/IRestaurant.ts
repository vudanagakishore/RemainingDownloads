export interface IRestaurant
{
    id: number;
    name : string;
    address : string;
    category : string;
}