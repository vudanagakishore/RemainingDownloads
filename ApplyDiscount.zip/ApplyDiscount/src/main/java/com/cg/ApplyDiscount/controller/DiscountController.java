package com.cg.ApplyDiscount.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ApplyDiscount.bean.Discount;
import com.cg.ApplyDiscount.service.IDiscountService;


@CrossOrigin()
@RestController

public class DiscountController {
	@Autowired
     IDiscountService discountService;
	
	@PostMapping("/adddiscount")
	public List<Discount> CreateDiscount(@RequestBody Discount discount) 
	{
		return discountService.CreateDiscount(discount);
	}
}
	
	