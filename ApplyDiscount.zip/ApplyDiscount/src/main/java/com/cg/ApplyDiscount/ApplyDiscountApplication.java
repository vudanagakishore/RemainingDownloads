package com.cg.ApplyDiscount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplyDiscountApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplyDiscountApplication.class, args);
	}

}
