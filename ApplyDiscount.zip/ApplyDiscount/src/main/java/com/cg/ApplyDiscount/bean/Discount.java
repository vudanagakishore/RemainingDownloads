package com.cg.ApplyDiscount.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

//public class Discount {
//	
//
//}
@Entity

@Table(name="Discount_Capg")
public class Discount 
{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", updatable = false, nullable = false)
	private int id;
	@Min(2000)
	@Max(40000)

	private float price;

	private String discount;
	
	
	private float finalPrice;

	/**
	 * 
	 */
	public Discount() {
		super();
	}

	/**
	 * @param id
	 * @param price
	 * @param discount
	 * @param finalPrice
	 */
	public Discount(int id,float price, String discount, float finalPrice) {
		super();
		this.id = id;
		this.price = price;
		this.discount = discount;
		this.finalPrice = finalPrice;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}

	/**
	 * @return the discount
	 */
	public String getDiscount() {
		return discount;
	}

	/**
	 * @param discount the discount to set
	 */
	public void setDiscount(String discount) {
		this.discount = discount;
	}

	/**
	 * @return the finalPrice
	 */
	public float getFinalPrice() {
		return finalPrice;
	}

	/**
	 * @param finalPrice the finalPrice to set
	 */
	public void setFinalPrice(float finalPrice) {
		this.finalPrice = finalPrice;
	}

	
	@Override
	public String toString() {
		return "Discount [id=" + id + ", price=" + price + ", discount=" + discount + ", finalPrice=" + finalPrice
				+ "]";
	}

	
	
	
	
	
	
	
	
	
}
	