package com.cg.ApplyDiscount.service;

import java.util.List;

import com.cg.ApplyDiscount.bean.Discount;

public interface IDiscountService {

	public List<Discount> CreateDiscount(Discount discount);

}
