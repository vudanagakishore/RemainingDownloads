package com.cg.ApplyDiscount.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ApplyDiscount.bean.Discount;

@Repository
public interface IDiscountDao extends JpaRepository<Discount,Integer>{ 

	

}
