package com.cg.ApplyDiscount.exception;

public class DiscountException extends Exception {

	public DiscountException()
    {
        super();
    }
    public DiscountException(String msg)
    {
        super(msg);
    }


}
