package com.cg.ApplyDiscount.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ApplyDiscount.bean.Discount;
import com.cg.ApplyDiscount.dao.IDiscountDao;
@Service
public class DiscountServiceImpl implements IDiscountService {
@Autowired

  IDiscountDao discountdao;

	@Override
	public List<Discount> CreateDiscount(Discount discount) {
		
		if(discount.getPrice()>2000)
		{
		String temp = "Your Discount is 20%";
		discount.setDiscount(temp);
		float discountAmount = (discount.getPrice()*20)/100;
		float discountPrice = discount.getPrice()-discountAmount;
		discount.setFinalPrice(discountPrice);
		discountdao.save(discount);
		}
		else
		{
			float discountAmount = (float) ((discount.getPrice()*0.5)/100);
			float discountPrice = discount.getPrice()-discountAmount;
			discount.setFinalPrice(discountPrice);
			discountdao.save(discount);
			
		}
		return discountdao.findAll();
		
	}

}
