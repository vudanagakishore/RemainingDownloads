export class Customer {
    accountNo:  number;
    name: String;
    pin: number;
    balance: number;
constructor(accountNo:number,name:String,pin:number,balance:number){
    this.accountNo = accountNo;
    this.name = name;
    this.pin = pin;
    this.balance = balance;
}
}
