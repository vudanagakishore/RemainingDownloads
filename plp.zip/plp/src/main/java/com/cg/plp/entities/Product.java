package com.cg.plp.entities;

//import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CapStore_Products")
public class Product {
	@Id
//	@Column(name="Product_Id")
	private int productId;
//	@Column(name="Product_Name")
	private String productName;
//	@Column(name="Product_Category")
	private String productCategory;
//	@OneToOne(targetEntity=Inventory.class)
//    private Inventory inventory;

	public Product() {
		super();
	}

	public Product(String productName, String productCategory) {
		super();
		this.productName = productName;
		this.productCategory = productCategory;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	@Override
	public String toString() {
		return "Search [productName=" + productName + ", productCategory=" + productCategory + "]";
	}

}
