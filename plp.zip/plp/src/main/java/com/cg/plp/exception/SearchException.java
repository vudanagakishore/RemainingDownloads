package com.cg.plp.exception;

public class SearchException extends Exception{

	public SearchException() {
		super();
	}
	
	public SearchException(String message) {
		super(message);
	}
}