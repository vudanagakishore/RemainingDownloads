package com.cg.plp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.plp.entities.Customer;
import com.cg.plp.entities.Inventory;
import com.cg.plp.entities.Merchant;
import com.cg.plp.entities.Product;

@Repository
public interface SearchDao extends JpaRepository<Product, String> {

	@Query("from Product product where product.productName= :productName")
	List<Product> findByName(@Param("productName") String productName);

	@Query("from Product product where product.productCategory= :productCategory")
	List<Product> findByCategory(@Param("productCategory") String productCategory);

	@Query("from Customer customer where customer.customerName= :customerName")
	List<Customer> searchCustomerByName(String customerName);

	@Query("from Customer customer where customer.customerId= :customerId")
	List<Customer> searchCustomerById(int customerId);

	@Query("from Merchant merchant where merchant.merchantName= :merchantName")
	List<Merchant> searchMerchantByName(String merchantName);

	@Query("from Merchant merchant where merchant.merchantId= :merchantId")
	List<Merchant> searchMerchantById(int merchantId);

	@Query("from Inventory inventory where inventory.inventoryId= :inventoryId")
	List<Inventory> searchInventoryById(int inventoryId);

}
