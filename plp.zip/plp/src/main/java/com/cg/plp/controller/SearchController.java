package com.cg.plp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.plp.entities.Customer;
import com.cg.plp.entities.Inventory;
import com.cg.plp.entities.Merchant;
import com.cg.plp.entities.Product;
import com.cg.plp.exception.SearchException;
import com.cg.plp.service.SearchService;

@RestController
public class SearchController {

	@Autowired
	SearchService searchService;

	@RequestMapping("/searchAll")
	public List<Product> findAllProducts() throws SearchException {
		return searchService.findAllProducts();

	}

	@RequestMapping(value = "/searchByName/{productName}")
	public List<Product> findByName(@PathVariable String productName) throws SearchException {
		return searchService.findByName(productName);

	}

	@RequestMapping(value = "/searchByCategory/{productCategory}")
	public List<Product> findByCategory(@PathVariable String productCategory) throws SearchException {
		return searchService.findByCategory(productCategory);

	}

	@RequestMapping(value = "/admin/searchCustomerByName/{customerName}")
	public List<Customer> searchCustomerByName(@PathVariable String customerName) throws SearchException {
		return searchService.searchCustomerByName(customerName);

	}

	@RequestMapping(value = "/admin/searchCustomerById/{customerId}")
	public List<Customer> searchCustomerById(@PathVariable int customerId) throws SearchException {
		return searchService.searchCustomerById(customerId);

	}

	@RequestMapping(value = "/admin/searchMerchantByName/{merchantName}")
	public List<Merchant> searchMerchantByName(@PathVariable String merchantName) throws SearchException {
		return searchService.searchMerchantByName(merchantName);

	}

	@RequestMapping(value = "/admin/searchMerchantById/{merchantId}")
	public List<Merchant> searchMerchantById(@PathVariable int merchantId) throws SearchException {
		return searchService.searchMerchantById(merchantId);

	}

	@RequestMapping(value = "/merchant/searchInventoryById/{inventoryId}")
	public List<Inventory> searchInventoryById(@PathVariable int inventoryId) throws SearchException {
		return searchService.searchInventoryById(inventoryId);
	}
}
