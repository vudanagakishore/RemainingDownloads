package com.cg.plp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.plp.dao.SearchDao;
import com.cg.plp.entities.Customer;
import com.cg.plp.entities.Inventory;
import com.cg.plp.entities.Merchant;
import com.cg.plp.entities.Product;
import com.cg.plp.exception.SearchException;

@Service
public class SearchServiceImpl implements SearchService {

	@Autowired
	SearchDao searchDAO;

	@Override
	public List<Product> findAllProducts() throws SearchException{
		try {
		return searchDAO.findAll();
		}catch(Exception e){
			throw new SearchException("Can't find any product");
		}
	}

	@Override
	public List<Product> findByName(String productName) throws SearchException {
		try {
		return searchDAO.findByName(productName);
		}catch(Exception e) {
			throw new SearchException("Can't find any product by this Name");
		}
	}

	@Override
	public List<Product> findByCategory(String productCategory) throws SearchException {
		try {
		return searchDAO.findByCategory(productCategory);
		}catch(Exception e) {
			throw new SearchException("Can't find any product in this Category");
		}
	}

	@Override
	public List<Customer> searchCustomerByName(String customerName) throws SearchException {
		try {
		return searchDAO.searchCustomerByName(customerName);
		}catch(Exception e) {
			throw new SearchException("Can't find any customer by this Name");
		}
	}

	@Override
	public List<Customer> searchCustomerById(int customerId) throws SearchException {
		try {
		return searchDAO.searchCustomerById(customerId);
		}catch(Exception e) {
			throw new SearchException("Can't find any customer by this ID");
		}
	}

	@Override
	public List<Merchant> searchMerchantByName(String merchantName) throws SearchException {
		try {
		return searchDAO.searchMerchantByName(merchantName);
		}catch(Exception e) {
			throw new SearchException("Can't find any merchant by this Name");
		}
	}

	@Override
	public List<Merchant> searchMerchantById(int merchantId) throws SearchException {
		try {
		return searchDAO.searchMerchantById(merchantId);
		}catch(Exception e) {
			throw new SearchException("Can't find any merchant by this ID");
		}
	}

	@Override
	public List<Inventory> searchInventoryById(int inventoryId) throws SearchException {
		try {
		return searchDAO.searchInventoryById(inventoryId);
		}catch(Exception e) {
			throw new SearchException("Can't find any inventory by this ID");
		}
	}

}
