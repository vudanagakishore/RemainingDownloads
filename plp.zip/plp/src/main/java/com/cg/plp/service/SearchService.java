package com.cg.plp.service;

import java.util.List;

import com.cg.plp.entities.Customer;
import com.cg.plp.entities.Inventory;
import com.cg.plp.entities.Merchant;
import com.cg.plp.entities.Product;
import com.cg.plp.exception.SearchException;

public interface SearchService {
	
	List<Product> findAllProducts() throws SearchException;

	List<Product> findByName(String productName) throws SearchException;

	List<Product> findByCategory(String productCategory) throws SearchException;

	List<Customer> searchCustomerByName(String customerName) throws SearchException;

	List<Customer> searchCustomerById(int customerId) throws SearchException;

	List<Merchant> searchMerchantByName(String merchantName) throws SearchException;

	List<Merchant> searchMerchantById(int merchantId) throws SearchException;

	List<Inventory> searchInventoryById(int inventoryId) throws SearchException;

}
