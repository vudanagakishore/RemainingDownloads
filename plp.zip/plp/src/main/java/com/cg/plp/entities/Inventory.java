package com.cg.plp.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Inventory {

	@Id
	private int inventoryId;
//	@Column(name = "merchanntId")
	@OneToOne(targetEntity = Merchant.class)
	private Merchant merchant;
//	@Column
	private String productName;
//	@Column
	private String productCategory;

	public Inventory() {
		super();
	}

	public Inventory(int inventoryId, Merchant merchant, String productName, String productCategory) {
		super();
		this.inventoryId = inventoryId;
		this.merchant = merchant;
		this.productName = productName;
		this.productCategory = productCategory;
	}

	public int getInventoryId() {
		return inventoryId;
	}

	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	@Override
	public String toString() {
		return "Inventory [inventoryId=" + inventoryId + ", merchant=" + merchant + ", productName=" + productName
				+ ", productCategory=" + productCategory + "]";
	}

}
