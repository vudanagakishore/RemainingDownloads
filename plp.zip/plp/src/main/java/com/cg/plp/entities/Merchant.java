package com.cg.plp.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Merchant {
	@Id
	private int merchantId;
//	@Column
	private String merchantName;
//	@Column
	private long merchantContact;
//	@Column
	private String merchantEmail;
	@OneToOne(targetEntity=Product.class)
    private Product product;

	public Merchant() {
		super();
	}

	public Merchant(int merchantId, String merchantName, long merchantContact, String merchantEmail) {
		super();
		this.merchantId = merchantId;
		this.merchantName = merchantName;
		this.merchantContact = merchantContact;
		this.merchantEmail = merchantEmail;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public long getMerchantContact() {
		return merchantContact;
	}

	public void setMerchantContact(long merchantContact) {
		this.merchantContact = merchantContact;
	}

	public String getMerchantEmail() {
		return merchantEmail;
	}

	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}

	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", merchantName=" + merchantName + ", merchantContact="
				+ merchantContact + ", merchantEmail=" + merchantEmail + "]";
	}

}
