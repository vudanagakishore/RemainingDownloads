package com.cg.cr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

	@Autowired
	Login login;
	
	@RequestMapping("/loginPage")

	public String loginPage(Model model)
	{
		model.addAttribute("login", login);
		return "login";
	}
	
	@RequestMapping("/showPage")
	public String showPage(Login login,Model model)
	{
		String uname=login.getUsername();
		if(login.getUsername().equals("Aswin"))
		{
			model.addAttribute("uname", uname);
			return "success";
		}
		else
			return "login";
		
	}
	
	@RequestMapping("/showData")
	public String loginData(@RequestParam("uname") String username,@RequestParam("password") String password,Model model)
	{
		model.addAttribute("uname", username);
		model.addAttribute("password", password);
		return "success";
		
	}
}
