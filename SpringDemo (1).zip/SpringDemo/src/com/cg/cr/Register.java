package com.cg.cr;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class Register {
	@NotEmpty(message="Firstname should not be empty")
	@Size(min=3, max=8, message="min 3 or max 4")
	private String firstname;
	@NotEmpty(message="Lastname should not be empty")
	@Size(min=3, max=8, message="min 3 or max 4")
	private String lastname;
	private char gender;
	@NotEmpty(message="EMail should not be empty")
	@Email(message="enter Emails")
	private String[] email;
	private String skills;
	private String city;
	

	public String getFirstname() {
		return firstname;
	}
	
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	
	public String getLastname() {
		return lastname;
	}
	
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}
	
	public String[] getEmail() {
		return email;
	}
	
	public void setEmail(String[] email) {
		this.email = email;
	}
	
	
	public String getSkills() {
		return skills;
	}

	
	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	
}
