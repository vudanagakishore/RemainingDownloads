import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
import { IEmployee } from '../iemployee';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  constructor(private empservice:EmployeeService,private router:Router) { }
  ngOnInit() {
  }
  onSubmit(form:IEmployee){
    this.empservice.addEmployee(form);
    this.router.navigate(['/employees']);
  }
}
