package com.cg.springBootRest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springBootRest.bean.Product;
import com.cg.springBootRest.dao.ProductDao;
import com.cg.springBootRest.exception.ProductException;


@Service
public class ProductServiceImpl implements ProductService{
    
    @Autowired
    ProductDao productDao;

    @Override
    public List<Product> addProduct(Product pro) throws ProductException{
        
        try {
        	pro.setTotalprice(pro.getPrice()*pro.getQuantity());
            productDao.save(pro);
            return productDao.findAll();
        }
        catch(Exception e)
        {
          throw new ProductException("Cannot add");
        }

 

    }

    @Override
    public Product getProductById(long id) throws ProductException {
        try {
            return productDao.findById(id).get();
        }
        catch(Exception ex)
        {
        	throw new ProductException(ex.getMessage()+" No product with this id"+ id);
        }
    }

    @Override
    public void deleteProduct(long id) throws ProductException{
        try {
            productDao.deleteById(id);
        }

        catch(Exception e)
        {
        	throw new ProductException(e.getMessage()+"(Id not present) Cannot delete this id: "+ id); 
        }
        
    }

    @Override
    public List<Product> getAllProducts() throws ProductException{
        
        try {
            return productDao.findAll();
        }

        catch(Exception e)
        {
        	throw new ProductException(e.getMessage()+"(Id not present) Cannot delete this id: "); 
        }
    }
 
    @Override
    public List<Product> updateProduct(long id, Product pro) throws ProductException{
        
     try
        {
            Optional<Product> optional = productDao.findById(id);
            if(optional.isPresent())
            {
                Product product = optional.get();
                product.setName(pro.getName());
                product.setModel(pro.getModel());
                product.setQuantity(pro.getQuantity());
                product.setPrice(pro.getPrice());
                
                product.setTotalprice(pro.getPrice()*pro.getQuantity());
                productDao.save(product);
                return getAllProducts();
            }
            else
            {
            	throw new ProductException("(Id not present) "+ id); 
            }
        }
    catch(Exception e)
    {
    	throw new ProductException(e.getMessage()+"(Id not present) "+ id); 
    }
    
    }

	@Override
	public List<Product> getProductByPrice(int price) throws ProductException {
		 try
		 	{
				return productDao.findByPrice(price);
	        }
	        catch(Exception ex)
	        {
	        	throw new ProductException(ex.getMessage()+" No product greater than this price "+ price);
	        }
		
	}

	@Override
	public List<Product> getAllProductsByQty() throws ProductException {
	
		 try {
			 return  productDao.findByQty();
	        }
	        catch(Exception ex)
	        {
	        	throw new ProductException(ex.getMessage()+" No product greater than this price ");
	        }
		
		
	}

}