package com.cg;

public interface ExchangeService {
	public double getExchangeRate();
	

}
