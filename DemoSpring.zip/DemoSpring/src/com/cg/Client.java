package com.cg;

import org.springframework.core.io.Resource;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class Client {
	public static void main(String args[])
	{
		Resource resource=new ClassPathResource("currencyConverter.xml");
		BeanFactory factory=new XmlBeanFactory(resource);
		CurrencyConverter currency =(CurrencyConverter) factory.getBean("currencyConverter");
		double result =currency.dollarToRupees(50.0);
		System.out.println("50 dollar is "+result);
		
		


}
}