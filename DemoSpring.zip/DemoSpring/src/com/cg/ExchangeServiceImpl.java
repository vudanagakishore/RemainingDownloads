package com.cg;

public class ExchangeServiceImpl implements ExchangeService {
	private double exchangeRate;
	public ExchangeServiceImpl(double exchangeRate) {
		super();
		this.exchangeRate=exchangeRate;
		System.out.println("ExchangeServiceImpl() cons Invoked");
	
		
	}
	public double getExchangeRate()
	{
	System.out.println("getExchanegRate() Invoked");
	return exchangeRate;
	}
	
}
