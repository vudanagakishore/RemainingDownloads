package com.cg;

 

public class CurrencyConverterImpl implements CurrencyConverter {
    private ExchangeService exchangeService;
    
public CurrencyConverterImpl() {
        super();
        System.out.println("CurrencyCoverterImpl()");
    }
//private double exchangeRate;
//public CurrencyConverterImpl(double exchangeRate)
//{
//    super();
//    this.exchangeRate=exchangeRate;
//}
    @Override
    public double dollarToRupees(double dollars) {
        System.out.println("dollarToRupees() Invoked");
         return dollars*exchangeService.getExchangeRate();
    }
    public ExchangeService getExchangeService() {
        return exchangeService;
    }
    public void setExchangeService(ExchangeService exchangeService) {
        this.exchangeService = exchangeService;
    }
}