package com.cg.list;
import java.util.List;

 

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

 

public class ClientList {

 

    public static void main(String args[]) {
        
        Resource resource=new ClassPathResource("collection.xml");
        BeanFactory factory=new XmlBeanFactory(resource);
        CurrencyList list=(CurrencyList) factory.getBean("CurrencyList");
        List result=list.getCurrList();
        System.out.println(result);
    }
    
}