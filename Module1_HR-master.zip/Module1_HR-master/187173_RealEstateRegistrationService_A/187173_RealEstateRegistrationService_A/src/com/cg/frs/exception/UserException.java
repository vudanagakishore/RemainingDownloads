package com.cg.frs.exception;

public class UserException {

}
