package com.cg.springBootRest.service;
import java.util.List;

import com.cg.springBootRest.bean.Product;
import com.cg.springBootRest.exception.ProductException;


public interface ProductService {

	public List<Product> addProduct(Product pro) throws ProductException;
	public Product getProductById(Long id) throws ProductException;
	public void deleteProduct(Long id) throws ProductException;
	public List<Product> getAllProducts() throws ProductException;
	public List<Product> updateProduct(Long id,Product pro) throws ProductException;
	public Product getProductByPrice(int price) throws ProductException;
	public Product getAllProductsByQty() throws ProductException;
	
}

